#include <stdio.h>
#include <sleep.h>
#include <time.h>
#include <unistd.h>

#include "platform.h"
#include "xil_printf.h"
#include "xparameters.h"
#include "xgpio.h"
#include "xstatus.h"
#include "Delay.h"
#include "LCD_SPI.h"
#include "LCD_Driver.h"
#include "LCD_GUI.h"
#include "ADC.h"
#include "I2C.h"

#define INT_ID_BTN_Z0		61 //[7:0] --> [68:61]
#define INT_ID_BTN_Z1		62
#define INT_ID_BTN_Z2		63
#define INT_ID_BTN_Z3		64
#define INT_ID_BTN_B0		65
#define INT_ID_BTN_B1		66
#define INT_ID_BTN_BJS		67
#define INT_ID_TMR			68




int start_up();


int menu_inicio();



int test_rapido();

extern XGpio GPIO_LCD;
extern XGpio GPIO_SW;
extern XSpi  SPI_LCD;	 /* The instance of the SPI device */
extern XSpi  SPI_ADC;

int main(){
    int sel_inicio;

    startup();
	sel_inicio = menu_inicio();
	if (sel_inicio == -1){
		LCD_Clear(GUI_BACKGROUND);
		xil_printf("Proceso no fue comenzado");
		LCD_Clear(GUI_BACKGROUND);
		GUI_DisString_EN(42, 64, "Adios", &Font12, GUI_BACKGROUND, CYAN);
		sleep(10);
		LCD_Clear(GUI_BACKGROUND);
		return -1;
	}
	else if (sel_inicio == 0){
		LCD_Clear(GUI_BACKGROUND);
		test_botones();
	}
	else{
		LCD_Clear(GUI_BACKGROUND);
		test_rapido();
	}


}


int start_up(){

    int Status;

    init_platform();

    Status = init_IIC();
	if (Status != XST_SUCCESS) {
		xil_printf("IIC Mode Failed\r\n");
		return XST_FAILURE;
	}

    Status = XGpio_Initialize(&GPIO_LCD, XPAR_AXI_GPIO_0_DEVICE_ID); // Revisar ID
	if (Status != XST_SUCCESS) {
		xil_printf("GGPI-LCD Initialization Failed\r\n");
		return XST_FAILURE;
	}

    Status = XGpio_Initialize(&GPIO_SW, XPAR_AXI_GPIO_1_DEVICE_ID); // Revisar ID
	if (Status != XST_SUCCESS) {
		xil_printf("GPIO-SW Initialization Failed\r\n");
		return XST_FAILURE;
	}

	// Set up the AXI SPI Controller
	Status = XSpi_Init(&SPI_LCD, SPI_DEVICE_ID); // Revisar ID
	if (Status != XST_SUCCESS) {
		xil_printf("SPI-LCD Mode Failed\r\n");
		return XST_FAILURE;
	}

	Status = init_adc(&SPI_ADC, SPI_DEVICE_ID_1); // Revisar ID
	if (Status != XST_SUCCESS) {
		xil_printf("SPI-ADC Mode Failed\r\n");
		return XST_FAILURE;
	}
    xil_printf("TFT initialized \r\n");

	xil_printf("**********Init LCD**********\r\n");
	LCD_SCAN_DIR LCD_ScanDir = SCAN_DIR_DFT;//SCAN_DIR_DFT = D2U_L2R
	LCD_Init(LCD_ScanDir );

	xil_printf("LCD Show \r\n");
	//GUI_Show();
	//delay_ms(1000);
	LCD_Clear(GUI_BACKGROUND);
	GUI_INTRO();
    delay_ms(5000);
	LCD_Clear(GUI_BACKGROUND);

    return 0;
}


int menu_inicio(){
    
	GUI_IMG(booster);

    GUI_DisString_EN(15,8, "Hola! Presione",&Font12, GUI_BACKGROUND,CYAN);
    GUI_DisString_EN(22,24, "el boton del",&Font12, GUI_BACKGROUND,CYAN);
    GUI_DisString_EN(15,40, "modo de testeo",&Font12, GUI_BACKGROUND,CYAN);
	GUI_DisString_EN(65, 71, "-> Paso a", &Font12, GUI_BACKGROUND, CYAN);
	GUI_DisString_EN(99, 79, "paso", &Font12, GUI_BACKGROUND, CYAN);
	GUI_DisString_EN(65, 92, "-> Modo", &Font12, GUI_BACKGROUND, CYAN);
	GUI_DisString_EN(72, 71, "rapido", &Font12, GUI_BACKGROUND, CYAN);

	// Esperar el interrupt de los botones, retornar dependiendo del que se recibe.

	//if (BTN_BOOSTER1) {
	//    return 1;
	//}
	//else if (BTN_BOOSTER0) {
	return 0;
	//else{ // Timer Finished
	//    return -1;
	//}


}

int paso_a_paso(){

}

int test_rapido(){
	GUI_DisString_EN(15,8, "Presione los", &Font12, GUI_BACKGROUND,CYAN);
	GUI_DisString_EN(22,24, "botones", &Font12, GUI_BACKGROUND,CYAN);
	GUI_DisString_EN(15,40, "solo una vez", &Font12, GUI_BACKGROUND,CYAN);
	LCD_Clear(WHITE);
	delay_ms(1000);
	LCD_Clear(GUI_BACKGROUND);
	// Mostrar todo:
	GUI_DisString_EN(0, 0, "Zybo Z7-10", &Font12, GUI_BACKGROUND, WHITE); //Seccion Zybo

	GUI_DisString_EN(104, 0, "sw", &Font8, GUI_BACKGROUND, WHITE); //SW0
	GUI_DisString_EN(104, 8, "sw", &Font8, GUI_BACKGROUND, WHITE); //SW1
	GUI_DisString_EN(104, 16, "sw", &Font8, GUI_BACKGROUND, WHITE); //SW2
	GUI_DisString_EN(104, 24, "sw", &Font8, GUI_BACKGROUND, WHITE); //SW3

	GUI_DisString_EN(0, 24, "BOOSTER PACK", &Font12, GUI_BACKGROUND, WHITE); //Seccion Booster

	GUI_DisString_EN(0, 38, "Eje X", &Font8, GUI_BACKGROUND, WHITE); //Acelerometro X
	GUI_DisString_EN(0, 47, "Eje Y", &Font8, GUI_BACKGROUND, WHITE); //Acelerometro Y
	GUI_DisString_EN(0, 56, "Eje Z", &Font8, GUI_BACKGROUND, WHITE); //Acelerometro Z

	GUI_DisString_EN(48, 40, "T", &Font8, GUI_BACKGROUND, WHITE); //Temperatura
	GUI_DisString_EN(48, 48, "Mic", &Font8, GUI_BACKGROUND, WHITE); //Microfono
	GUI_DisString_EN(48, 56, "Luz", &Font8, GUI_BACKGROUND, WHITE); //Luz

	GUI_DisString_EN(0, 64, "Joystick", &Font12, GUI_BACKGROUND, WHITE); //Joystick

	GUI_DisString_EN(0, 80, "X actual", &Font8, GUI_BACKGROUND, WHITE); //Valores Joystick
	GUI_DisString_EN(0, 88, "Y actual", &Font8, GUI_BACKGROUND, WHITE);
	GUI_DisString_EN(0, 96, "X minimo", &Font8, GUI_BACKGROUND, WHITE);
	GUI_DisString_EN(0, 104, "X maximo", &Font8, GUI_BACKGROUND, WHITE);
	GUI_DisString_EN(0, 112, "Y minimo", &Font8, GUI_BACKGROUND, WHITE);
	GUI_DisString_EN(0, 120, "Y maximo", &Font8, GUI_BACKGROUND, WHITE);

	GUI_DisString_EN(64, 68, "Potenciometro", &Font8, GUI_BACKGROUND, WHITE); //Potenciometro

	GUI_DisString_EN(64, 80, "I actual", &Font8, GUI_BACKGROUND, WHITE); //Valores Potenciometro
	GUI_DisString_EN(64, 88, "D actual", &Font8, GUI_BACKGROUND, WHITE);
	GUI_DisString_EN(64, 96, "I minimo", &Font8, GUI_BACKGROUND, WHITE);
	GUI_DisString_EN(64, 104, "I maximo", &Font8, GUI_BACKGROUND, WHITE);
	GUI_DisString_EN(64, 112, "D minimo", &Font8, GUI_BACKGROUND, WHITE);
	GUI_DisString_EN(64, 120, "D maximo", &Font8, GUI_BACKGROUND, WHITE);


	refresh();



	//Interrupciones BTNs
}

void refresh(){
	
}

extern char pot1[16] = {};
extern char pot2[16] = {};
extern int pot1_min = 500;
extern int pot1_max = 500;
extern char p1_min[16] = {};
extern char p1_max[16] = {};
extern int pot2_min = 512;
extern int pot2_max = 512;
extern char p2_min[16] = {};
extern char p2_max[16] = {};

